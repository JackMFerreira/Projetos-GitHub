import React, { useState, useRef } from 'react';
import { Upload, FileText, X, CheckCircle, AlertCircle, BookOpen, Image as ImageIcon, Eye, Download } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';

// Configurar worker do PDF.js para usar o arquivo local
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();

interface EbookImporterProps {
  onClose: () => void;
  onImportSuccess: (images: string[]) => void;
  onImageSelected: (imageUrl: string) => void;
}

interface ExtractedPage {
  id: string;
  url: string;
  name: string;
  selected: boolean;
  pageNumber: number;
}

const EbookImporter: React.FC<EbookImporterProps> = ({ onClose, onImportSuccess, onImageSelected }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedPages, setExtractedPages] = useState<ExtractedPage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'upload' | 'select' | 'complete'>('upload');
  const [processingProgress, setProcessingProgress] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (file: File) => {
    if (!file) return;

    // Verificar se é um arquivo PDF
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      setError('Por favor, selecione um arquivo PDF! 📄');
      return;
    }

    setIsProcessing(true);
    setError(null);
    setProcessingProgress(0);

    try {
      const pages = await extractPagesFromPDF(file);
      
      if (pages.length === 0) {
        setError('Nenhuma página foi encontrada no PDF! 🔍');
        setIsProcessing(false);
        return;
      }

      setExtractedPages(pages);
      setStep('select');
    } catch (err) {
      console.error('Erro ao processar PDF:', err);
      setError('Erro ao processar o PDF. Verifique se o arquivo não está corrompido! ❌');
    } finally {
      setIsProcessing(false);
    }
  };

  const extractPagesFromPDF = async (file: File): Promise<ExtractedPage[]> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const numPages = pdf.numPages;
    setTotalPages(numPages);
    
    const pages: ExtractedPage[] = [];

    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      try {
        setProcessingProgress((pageNum / numPages) * 100);
        
        const page = await pdf.getPage(pageNum);
        const viewport = page.getViewport({ scale: 2.0 }); // Escala maior para melhor qualidade
        
        // Criar canvas para renderizar a página
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        if (!context) continue;
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // Renderizar página no canvas
        await page.render({
          canvasContext: context,
          viewport: viewport
        }).promise;
        
        // Aplicar filtros para tornar adequado para colorir
        const processedCanvas = applyColoringFilters(canvas);
        
        // Converter para data URL
        const dataUrl = processedCanvas.toDataURL('image/png');
        
        pages.push({
          id: `pdf-page-${pageNum}`,
          url: dataUrl,
          name: `Página ${pageNum}`,
          selected: true,
          pageNumber: pageNum
        });
        
      } catch (pageError) {
        console.error(`Erro ao processar página ${pageNum}:`, pageError);
        // Continuar com as outras páginas mesmo se uma falhar
      }
    }

    return pages;
  };

  const applyColoringFilters = (sourceCanvas: HTMLCanvasElement): HTMLCanvasElement => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return sourceCanvas;
    
    canvas.width = sourceCanvas.width;
    canvas.height = sourceCanvas.height;
    
    // Desenhar imagem original
    ctx.drawImage(sourceCanvas, 0, 0);
    
    // Obter dados da imagem
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    // Aplicar filtros para tornar adequado para colorir
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      
      // Converter para escala de cinza
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      
      // Aumentar contraste e tornar mais adequado para colorir
      const threshold = 200; // Ajustar conforme necessário
      const newValue = gray > threshold ? 255 : 0;
      
      // Se for muito claro, tornar branco; se escuro, tornar preto
      data[i] = newValue;     // R
      data[i + 1] = newValue; // G
      data[i + 2] = newValue; // B
      // Alpha permanece o mesmo
    }
    
    // Aplicar os dados processados
    ctx.putImageData(imageData, 0, 0);
    
    return canvas;
  };

  const togglePageSelection = (id: string) => {
    setExtractedPages(prev => 
      prev.map(page => 
        page.id === id ? { ...page, selected: !page.selected } : page
      )
    );
  };

  const selectAll = () => {
    setExtractedPages(prev => prev.map(page => ({ ...page, selected: true })));
  };

  const clearAll = () => {
    setExtractedPages(prev => prev.map(page => ({ ...page, selected: false })));
  };

  const handleImport = () => {
    const selectedPages = extractedPages.filter(page => page.selected).map(page => page.url);
    
    if (selectedPages.length === 0) {
      setError('Selecione pelo menos uma página para importar! 🎨');
      return;
    }

    onImportSuccess(selectedPages);
    setStep('complete');
    
    // Fechar após um breve delay
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    const pdfFile = files.find(file => 
      file.name.toLowerCase().endsWith('.pdf')
    );
    
    if (pdfFile) {
      handleFileSelect(pdfFile);
    } else {
      setError('Por favor, arraste um arquivo PDF! 📄');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const downloadPage = (page: ExtractedPage) => {
    const link = document.createElement('a');
    link.href = page.url;
    link.download = `${page.name.replace(/\s+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-white/20 p-3 rounded-full">
                <FileText className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">📚 Importar PDF de Colorir</h2>
                <p className="text-white/90">Carregue um PDF e extraia as páginas como desenhos para colorir!</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="bg-white/20 hover:bg-white/30 p-2 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {step === 'upload' && (
            <div className="text-center">
              <div
                className="border-4 border-dashed border-blue-300 rounded-2xl p-12 hover:border-blue-400 transition-colors cursor-pointer"
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf"
                  onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                  className="hidden"
                />
                
                {isProcessing ? (
                  <div className="flex flex-col items-center">
                    <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                    <h3 className="text-xl font-bold text-blue-700 mb-2">Processando PDF...</h3>
                    <p className="text-gray-600 mb-4">Extraindo páginas e preparando para colorir</p>
                    
                    {totalPages > 0 && (
                      <div className="w-full max-w-md">
                        <div className="bg-gray-200 rounded-full h-3 mb-2">
                          <div 
                            className="bg-gradient-to-r from-blue-500 to-indigo-500 h-3 rounded-full transition-all duration-300"
                            style={{ width: `${processingProgress}%` }}
                          ></div>
                        </div>
                        <p className="text-sm text-gray-600">
                          {Math.round(processingProgress)}% - Processando {totalPages} páginas
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-4 rounded-full shadow-lg mb-4">
                      <FileText className="w-12 h-12 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-blue-700 mb-2">
                      Selecione um PDF 📄
                    </h3>
                    <p className="text-lg text-gray-600 mb-4">
                      Arraste e solte ou clique para selecionar
                    </p>
                    <div className="bg-blue-50 p-6 rounded-xl border-2 border-blue-200 max-w-md">
                      <h4 className="font-bold text-blue-700 mb-2">💡 Tipos de PDF aceitos:</h4>
                      <ul className="text-blue-600 text-sm space-y-1">
                        <li>• Livros de colorir em PDF</li>
                        <li>• Desenhos para imprimir</li>
                        <li>• Ebooks com ilustrações</li>
                        <li>• Qualquer PDF com imagens</li>
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              {error && (
                <div className="mt-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl flex items-center">
                  <AlertCircle className="w-6 h-6 text-red-500 mr-3" />
                  <p className="text-red-600 font-medium">{error}</p>
                </div>
              )}
            </div>
          )}

          {step === 'select' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-800">Páginas Extraídas</h3>
                  <p className="text-gray-600">Selecione as páginas que deseja importar como desenhos para colorir</p>
                </div>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={selectAll}
                    className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-4 py-2 rounded-full font-bold transition-all transform hover:scale-105"
                  >
                    ✅ Selecionar Todas
                  </button>
                  <button
                    onClick={clearAll}
                    className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-4 py-2 rounded-full font-bold transition-all transform hover:scale-105"
                  >
                    🗑️ Limpar Seleção
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
                {extractedPages.map((page) => (
                  <div
                    key={page.id}
                    className={`relative p-4 rounded-2xl border-3 transition-all duration-300 ${
                      page.selected
                        ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-lg'
                        : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-md'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <div className={`p-2 rounded-full ${
                          page.selected
                            ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white'
                            : 'bg-gray-100 text-gray-600'
                        }`}>
                          <ImageIcon className="w-4 h-4" />
                        </div>
                        <h3 className={`font-bold text-sm ${
                          page.selected ? 'text-blue-700' : 'text-gray-700'
                        }`}>
                          {page.name}
                        </h3>
                      </div>
                      <button
                        onClick={() => togglePageSelection(page.id)}
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                          page.selected
                            ? 'border-blue-500 bg-blue-500'
                            : 'border-gray-300 hover:border-blue-400'
                        }`}
                      >
                        {page.selected && (
                          <span className="text-white text-sm">✓</span>
                        )}
                      </button>
                    </div>
                    
                    <div className="h-32 flex items-center justify-center bg-gray-50 rounded-xl mb-3 overflow-hidden">
                      <img
                        src={page.url}
                        alt={page.name}
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>

                    <div className="flex justify-between items-center">
                      <button
                        onClick={() => togglePageSelection(page.id)}
                        className={`flex-1 py-2 px-3 rounded-lg font-medium text-sm transition-all ${
                          page.selected
                            ? 'bg-blue-500 text-white hover:bg-blue-600'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {page.selected ? 'Selecionado' : 'Selecionar'}
                      </button>
                      
                      <button
                        onClick={() => {
                          onImageSelected(page.url);
                          onClose();
                        }}
                        className="ml-2 p-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors font-medium text-sm px-3"
                        title="Colorir esta página agora"
                      >
                        🎨 Colorir
                      </button>
                      
                      <button
                        onClick={() => downloadPage(page)}
                        className="ml-2 p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                        title="Baixar página"
                      >
                        <Download className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl border-2 border-blue-200">
                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-600">
                    <p className="font-medium">📊 Resumo da importação:</p>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                      <li>{extractedPages.length} página{extractedPages.length !== 1 ? 's' : ''} extraída{extractedPages.length !== 1 ? 's' : ''} do PDF</li>
                      <li>{extractedPages.filter(page => page.selected).length} selecionada{extractedPages.filter(page => page.selected).length !== 1 ? 's' : ''} para importar</li>
                      <li>Páginas processadas para colorir (preto e branco)</li>
                      <li>Desenhos serão adicionados à galeria do app</li>
                    </ul>
                  </div>
                  <button
                    onClick={handleImport}
                    disabled={extractedPages.filter(page => page.selected).length === 0}
                    className={`px-8 py-4 rounded-full font-bold text-lg transition-all transform hover:scale-105 flex items-center space-x-2 ${
                      extractedPages.filter(page => page.selected).length === 0
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white shadow-lg'
                    }`}
                  >
                    <Upload className="w-6 h-6" />
                    <span>Importar Páginas! 🎨</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 'complete' && (
            <div className="text-center py-12">
              <div className="bg-gradient-to-r from-green-500 to-green-600 p-4 rounded-full shadow-lg mb-6 inline-block">
                <CheckCircle className="w-16 h-16 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-green-700 mb-4">
                🎉 PDF Importado com Sucesso!
              </h3>
              <p className="text-lg text-gray-600 mb-6">
                As páginas foram processadas e adicionadas à sua galeria como desenhos para colorir!
              </p>
              <div className="bg-green-50 p-6 rounded-2xl border-2 border-green-200">
                <p className="text-green-700 font-medium">
                  ✨ Agora você pode encontrar os novos desenhos na galeria principal do aplicativo!<br/>
                  🎨 Todas as páginas foram convertidas para preto e branco, perfeitas para colorir!
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EbookImporter;