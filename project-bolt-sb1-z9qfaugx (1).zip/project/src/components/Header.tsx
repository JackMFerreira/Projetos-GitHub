import React from 'react';
import { Palette, Sparkles, QrCode } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 p-6 shadow-xl relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-2 left-10 text-yellow-300 opacity-70">
          <Sparkles className="w-6 h-6 animate-pulse" />
        </div>
        <div className="absolute top-4 right-20 text-yellow-300 opacity-50">
          <Sparkles className="w-4 h-4 animate-pulse" style={{ animationDelay: '0.5s' }} />
        </div>
        <div className="absolute bottom-3 left-1/4 text-yellow-300 opacity-60">
          <Sparkles className="w-5 h-5 animate-pulse" style={{ animationDelay: '1s' }} />
        </div>
        <div className="absolute bottom-2 right-1/3 text-yellow-300 opacity-40">
          <Sparkles className="w-3 h-3 animate-pulse" style={{ animationDelay: '1.5s' }} />
        </div>
      </div>
      
      <div className="container mx-auto flex items-center justify-between relative z-10">
        {/* QR Code do Pix - Lado esquerdo */}
        <div className="bg-white/20 backdrop-blur-sm rounded-xl shadow-lg p-3 border border-white/30 max-w-[140px] hidden md:block">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <QrCode className="w-3 h-3 text-white mr-1" />
              <span className="text-xs font-medium text-white">PIX</span>
            </div>
            <img 
              src="/pix jack.jpg" 
              alt="QR Code PIX" 
              className="w-full h-auto rounded-lg border border-white/30 mb-2"
            />
            <p className="text-xs text-white/90 leading-tight">
              Seu Pix ajuda nosso app a crescer e melhorar.
            </p>
          </div>
        </div>
        
        {/* Título central */}
        <div className="bg-white/20 backdrop-blur-sm p-3 rounded-full mr-4 shadow-lg">
          <Palette className="text-white h-10 w-10" />
        </div>
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-white drop-shadow-lg">
            🎨 Colorir é Divertido! 🎨
          </h1>
          <p className="text-white/90 text-sm md:text-base mt-1 font-medium">
            Solte sua criatividade e pinte o mundo com suas cores favoritas!
          </p>
        </div>
        
        {/* Espaço vazio para balanceamento */}
        <div className="w-[140px] hidden md:block"></div>
      </div>
    </header>
  );
};

export default Header;