import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

const Instructions: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-200 rounded-2xl shadow-lg overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full p-4 flex items-center justify-between hover:bg-yellow-100/50 transition-colors"
      >
        <div className="flex items-center">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-400 p-2 rounded-full mr-3">
            <HelpCircle className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-lg font-bold text-yellow-800">
            Como usar o aplicativo? 
            <span className="text-sm font-normal text-yellow-600 ml-2">
              (Clique para {isExpanded ? 'esconder' : 'ver'} as instruções)
            </span>
          </h3>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-6 h-6 text-yellow-600" />
        ) : (
          <ChevronDown className="w-6 h-6 text-yellow-600" />
        )}
      </button>
      
      {isExpanded && (
        <div className="px-6 pb-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold text-yellow-800 mb-3 flex items-center">
                <span className="bg-yellow-400 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-2">1</span>
                Escolha sua Ferramenta:
              </h4>
              <ul className="space-y-2 text-yellow-700">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-blue-400 rounded-full mr-2"></span>
                  <strong>Pincel:</strong> Para desenhar livremente
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                  <strong>Região:</strong> Para selecionar áreas específicas
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <strong>Mágico:</strong> Para pintar áreas automaticamente
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-red-400 rounded-full mr-2"></span>
                  <strong>Borracha:</strong> Para apagar desenhos
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold text-yellow-800 mb-3 flex items-center">
                <span className="bg-yellow-400 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-2">2</span>
                Passos para Colorir:
              </h4>
              <ol className="list-decimal pl-5 space-y-2 text-yellow-700">
                <li>Ajuste o tamanho da ferramenta</li>
                <li>Escolha uma cor bonita</li>
                <li>Clique e arraste na imagem</li>
                <li>Use "Desfazer" se precisar corrigir</li>
                <li>Salve seu desenho quando terminar!</li>
              </ol>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-white/60 rounded-xl">
            <p className="text-center text-yellow-800 font-medium">
              🎨 <strong>Dica:</strong> Experimente diferentes ferramentas e cores para criar desenhos únicos e divertidos! 
              O botão de som pode ser ligado/desligado no canto superior direito.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Instructions;