import React, { useRef, useEffect, useState } from 'react';
import { Point, Region } from '../types';

interface CanvasProps {
  imageUrl: string;
  selectedColor: string | null;
  onRegionCreated: (region: Region) => void;
}

const Canvas: React.FC<CanvasProps> = ({ imageUrl, selectedColor, onRegionCreated }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<Point[]>([]);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.src = imageUrl;
    
    img.onload = () => {
      const containerWidth = containerRef.current?.clientWidth || 800;
      const scale = containerWidth / img.width;
      const width = containerWidth;
      const height = img.height * scale;
      
      setCanvasSize({ width, height });
      canvas.width = width;
      canvas.height = height;
      
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
    };
  }, [imageUrl]);

  const redrawCanvas = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw original image
    const img = new Image();
    img.src = imageUrl;
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    // Draw current path
    if (currentPath.length > 0) {
      ctx.beginPath();
      ctx.moveTo(currentPath[0].x, currentPath[0].y);
      
      currentPath.forEach(point => {
        ctx.lineTo(point.x, point.y);
      });
      
      ctx.strokeStyle = '#FF0000';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  };

  const getMousePos = (canvas: HTMLCanvasElement, evt: React.MouseEvent): Point => {
    const rect = canvas.getBoundingClientRect();
    return {
      x: evt.clientX - rect.left,
      y: evt.clientY - rect.top
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    setIsDrawing(true);
    const point = getMousePos(canvasRef.current, e);
    setCurrentPath([point]);
    redrawCanvas();
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;
    
    const point = getMousePos(canvasRef.current, e);
    setCurrentPath(prev => [...prev, point]);
    redrawCanvas();
  };

  const handleMouseUp = () => {
    if (!isDrawing || currentPath.length < 3) {
      setIsDrawing(false);
      setCurrentPath([]);
      return;
    }

    const newRegion: Region = {
      id: Date.now().toString(),
      points: [...currentPath],
      color: null
    };
    
    onRegionCreated(newRegion);
    setIsDrawing(false);
    setCurrentPath([]);
  };

  return (
    <div 
      ref={containerRef}
      className="relative bg-white rounded-lg shadow-lg overflow-hidden"
    >
      <canvas
        ref={canvasRef}
        width={canvasSize.width}
        height={canvasSize.height}
        className="cursor-crosshair"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
      {isDrawing && (
        <div className="absolute top-2 left-2 bg-purple-600 text-white py-1 px-3 rounded-full text-xs">
          Desenhando região...
        </div>
      )}
      <div className="absolute bottom-2 right-2 bg-white bg-opacity-70 px-3 py-1 rounded-full text-xs text-gray-700">
        Desenhe ao redor da área que você quer colorir
      </div>
    </div>
  );
};

export default Canvas;