import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Camera, Sparkles } from 'lucide-react';

interface ImageUploadProps {
  onImageUploaded: (imageUrl: string) => void;
}

const ImageUpload: React.FC<ImageUploadProps> = ({ onImageUploaded }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    setError(null);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Por favor, selecione um arquivo de imagem válido! 📸');
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      setError('A imagem é muito grande! Por favor, escolha uma imagem menor que 10MB.');
      return;
    }

    setIsLoading(true);
    const reader = new FileReader();
    
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const image = new Image();
        image.src = reader.result;
        
        image.onload = () => {
          setPreview(reader.result);
          onImageUploaded(reader.result);
          setIsLoading(false);
        };

        image.onerror = () => {
          setError('Erro ao carregar a imagem. Tente outra imagem! 😕');
          setIsLoading(false);
        };
      }
    };

    reader.onerror = () => {
      setError('Erro ao ler o arquivo. Tente novamente! 🔄');
      setIsLoading(false);
    };

    reader.readAsDataURL(file);
  };

  const handleButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const resetUpload = () => {
    setPreview(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="mb-6">
      {!preview ? (
        <div 
          className={`border-4 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer transform hover:scale-105 ${
            isDragging 
              ? 'border-purple-500 bg-gradient-to-br from-purple-50 to-pink-50 scale-105' 
              : 'border-purple-300 hover:border-purple-400 bg-gradient-to-br from-purple-25 to-pink-25'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={handleButtonClick}
        >
          <input 
            type="file" 
            className="hidden" 
            accept="image/*" 
            onChange={handleFileChange}
            ref={fileInputRef}
          />
          
          <div className="flex flex-col items-center">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-4 rounded-full shadow-lg mb-4">
              {isLoading ? (
                <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Upload className="w-12 h-12 text-white" />
              )}
            </div>
            
            <h3 className="text-2xl font-bold text-purple-700 mb-2">
              {isLoading ? 'Carregando sua imagem...' : 'Envie sua Própria Imagem! 📸'}
            </h3>
            
            <p className="text-lg text-gray-600 mb-4">
              Arraste e solte uma imagem aqui
            </p>
            
            <div className="flex items-center space-x-2 text-purple-600">
              <Camera className="w-5 h-5" />
              <span className="font-medium">ou clique para selecionar um arquivo</span>
              <Sparkles className="w-5 h-5" />
            </div>
            
            <p className="text-sm text-gray-500 mt-4">
              Formatos aceitos: JPG, PNG, GIF (máximo 10MB)
            </p>
          </div>
          
          {error && (
            <div className="mt-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl">
              <p className="text-red-600 font-medium">{error}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center bg-white p-6 rounded-2xl shadow-lg border-2 border-purple-100">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-green-500 to-green-600 p-2 rounded-full mr-3">
              <ImageIcon className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-green-700">
              Imagem carregada com sucesso! 🎉
            </h3>
          </div>
          
          <div className="relative inline-block">
            <img 
              src={preview} 
              alt="Pré-visualização da imagem para colorir" 
              className="max-h-[40vh] mx-auto rounded-xl shadow-md border-2 border-purple-100" 
            />
            <div className="absolute top-2 right-2 bg-green-500 text-white p-2 rounded-full shadow-lg">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          
          <button
            onClick={resetUpload}
            className="mt-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-3 px-6 rounded-full transition-all transform hover:scale-105 shadow-lg"
          >
            Escolher Outra Imagem 🔄
          </button>
        </div>
      )}
    </div>
  );
};

export default ImageUpload;