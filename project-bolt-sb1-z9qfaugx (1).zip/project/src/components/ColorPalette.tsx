import React from 'react';
import { ColorOption } from '../types';
import { Sparkles } from 'lucide-react';

interface ColorPaletteProps {
  colors: ColorOption[];
  selectedColor: string | null;
  onSelectColor: (color: string) => void;
}

const ColorPalette: React.FC<ColorPaletteProps> = ({ 
  colors, 
  selectedColor, 
  onSelectColor 
}) => {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-purple-100">
      <div className="flex items-center justify-center mb-6">
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-2 rounded-full mr-3">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <h3 className="text-xl font-bold text-purple-700">Paleta de Cores</h3>
      </div>
      
      <div className="grid grid-cols-4 gap-3">
        {colors.map((color) => (
          <button
            key={color.value}
            className={`relative w-12 h-12 rounded-xl shadow-md transition-all duration-300 transform hover:scale-110 ${
              selectedColor === color.value 
                ? 'ring-4 ring-purple-400 ring-offset-2 scale-110 shadow-lg' 
                : 'hover:shadow-lg'
            }`}
            style={{ backgroundColor: color.value }}
            onClick={() => onSelectColor(color.value)}
            title={color.name}
            aria-label={`Selecionar cor ${color.name}`}
          >
            {selectedColor === color.value && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md">
                  <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                </div>
              </div>
            )}
            
            {/* Hover effect */}
            <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 hover:opacity-100 transition-opacity duration-300" />
          </button>
        ))}
      </div>
      
      {selectedColor && (
        <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl text-center">
          <p className="text-sm font-medium text-purple-700">
            Cor selecionada: <span className="font-bold">
              {colors.find(c => c.value === selectedColor)?.name}
            </span>
          </p>
          <div 
            className="w-8 h-8 rounded-full mx-auto mt-2 shadow-md border-2 border-white"
            style={{ backgroundColor: selectedColor }}
          />
        </div>
      )}
    </div>
  );
};

export default ColorPalette;