import React, { useRef, useEffect, useState } from 'react';
import { Region, Point, BrushStyle } from '../types';
import { Download, Sparkles, Palette, Heart, Printer } from 'lucide-react';

interface ColoringCanvasProps {
  imageUrl: string;
  regions: Region[];
  selectedColor: string | null;
  brushStyle: BrushStyle;
  brushSize: number;
  onRegionCreated: (region: Region) => void;
}

const ColoringCanvas: React.FC<ColoringCanvasProps> = ({ 
  imageUrl, 
  regions,
  selectedColor,
  brushStyle,
  brushSize,
  onRegionCreated,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<Point[]>([]);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const [originalImageData, setOriginalImageData] = useState<ImageData | null>(null);
  const [coloredImageData, setColoredImageData] = useState<ImageData | null>(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const successMessages = [
    '🎨 Que lindo! Continue colorindo!',
    '✨ Você é um artista incrível!',
    '🌈 Cores maravilhosas!',
    '🎉 Fantástico! Que talento!',
    '💖 Adorei suas cores!',
    '🌟 Você está indo muito bem!',
    '🦋 Que desenho colorido!',
    '🎪 Que criatividade!'
  ];

  useEffect(() => {
    if (!imageUrl) {
      setImageLoaded(false);
      setOriginalImageData(null);
      setColoredImageData(null);
      setIsLoading(false);
      return;
    }

    loadImageToCanvas();
  }, [imageUrl]);

  useEffect(() => {
    redrawCanvas();
  }, [regions, selectedColor, brushStyle, imageLoaded, originalImageData, currentPath, isDrawing]);

  const loadImageToCanvas = () => {
    if (!canvasRef.current || !containerRef.current || !imageUrl) {
      return;
    }

    setIsLoading(true);
    setImageLoaded(false);
    setOriginalImageData(null);
    setColoredImageData(null);

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      setIsLoading(false);
      return;
    }

    const img = new Image();
    
    // Configurar crossOrigin apenas para URLs externas
    if (!imageUrl.startsWith('data:')) {
      img.crossOrigin = 'anonymous';
    }
    
    img.onload = () => {
      try {
        // Calcular dimensões
        const containerWidth = containerRef.current?.clientWidth || 800;
        const maxWidth = Math.min(containerWidth - 40, 800);
        const maxHeight = 600;

        const imgWidth = img.naturalWidth || img.width || 400;
        const imgHeight = img.naturalHeight || img.height || 400;

        const scaleX = maxWidth / imgWidth;
        const scaleY = maxHeight / imgHeight;
        const scale = Math.min(scaleX, scaleY, 1);

        const finalWidth = Math.floor(imgWidth * scale);
        const finalHeight = Math.floor(imgHeight * scale);

        // Configurar canvas
        canvas.width = finalWidth;
        canvas.height = finalHeight;
        setCanvasSize({ width: finalWidth, height: finalHeight });

        // Limpar canvas com fundo branco
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, finalWidth, finalHeight);
        
        // Desenhar imagem
        ctx.drawImage(img, 0, 0, finalWidth, finalHeight);

        // Aplicar filtros para tornar adequado para colorir
        applyColoringFilters(ctx, finalWidth, finalHeight);

        // Salvar dados da imagem original (preto e branco)
        const processedImageData = ctx.getImageData(0, 0, finalWidth, finalHeight);
        setOriginalImageData(processedImageData);
        
        // Inicializar imagem colorida como cópia da original
        const coloredData = new ImageData(
          new Uint8ClampedArray(processedImageData.data),
          finalWidth,
          finalHeight
        );
        setColoredImageData(coloredData);
        
        setImageLoaded(true);
        setIsLoading(false);

      } catch (error) {
        console.error('Erro ao processar imagem:', error);
        setIsLoading(false);
      }
    };

    img.onerror = () => {
      console.error('Erro ao carregar imagem');
      setIsLoading(false);
    };

    img.src = imageUrl;
  };

  const applyColoringFilters = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    try {
      const imageData = ctx.getImageData(0, 0, width, height);
      const data = imageData.data;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const a = data[i + 3];

        // Pular pixels transparentes
        if (a === 0) continue;

        // Calcular luminosidade
        const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
        
        // Detectar se é uma imagem com fundo escuro (como a que você mostrou)
        const isDarkBackground = luminance < 128;
        
        if (isDarkBackground) {
          // Para imagens com fundo escuro, inverter as cores
          // Pixels escuros (linhas) ficam pretos, pixels claros (fundo) ficam brancos
          if (luminance < 100) {
            // Pixel escuro - tornar preto (linha do desenho)
            data[i] = 0;     // R
            data[i + 1] = 0; // G
            data[i + 2] = 0; // B
          } else {
            // Pixel claro - tornar branco (fundo)
            data[i] = 255;     // R
            data[i + 1] = 255; // G
            data[i + 2] = 255; // B
          }
        } else {
          // Para imagens normais, aplicar filtro de escala de cinza com contraste
          const threshold = 180;
          
          if (luminance > threshold) {
            // Pixel claro - tornar branco (fundo)
            data[i] = 255;     // R
            data[i + 1] = 255; // G
            data[i + 2] = 255; // B
          } else {
            // Pixel escuro - tornar preto (linha)
            data[i] = 0;       // R
            data[i + 1] = 0;   // G
            data[i + 2] = 0;   // B
          }
        }
      }

      ctx.putImageData(imageData, 0, 0);
    } catch (error) {
      console.error('Erro ao aplicar filtros:', error);
    }
  };

  const hexToRgb = (hex: string): [number, number, number] => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [
      parseInt(result[1], 16),
      parseInt(result[2], 16),
      parseInt(result[3], 16)
    ] : [0, 0, 0];
  };

  const isWhitePixel = (r: number, g: number, b: number): boolean => {
    return r > 200 && g > 200 && b > 200;
  };

  const isBlackPixel = (r: number, g: number, b: number): boolean => {
    return r < 50 && g < 50 && b < 50;
  };

  const floodFill = (startX: number, startY: number): Point[] => {
    if (!coloredImageData || !canvasRef.current) return [];

    const canvas = canvasRef.current;
    const width = canvas.width;
    const height = canvas.height;

    const pixels = new Uint8ClampedArray(coloredImageData.data);
    const startIndex = (startY * width + startX) * 4;
    const startR = pixels[startIndex];
    const startG = pixels[startIndex + 1];
    const startB = pixels[startIndex + 2];

    // Não preencher se clicar em uma linha preta
    if (isBlackPixel(startR, startG, startB)) {
      return [];
    }

    const points: Point[] = [];
    const visited = new Set<string>();
    const stack: [number, number][] = [[startX, startY]];

    while (stack.length > 0 && points.length < 15000) {
      const [x, y] = stack.pop()!;
      const key = `${x},${y}`;

      if (visited.has(key)) continue;
      if (x < 0 || x >= width || y < 0 || y >= height) continue;

      const index = (y * width + x) * 4;
      const currentR = pixels[index];
      const currentG = pixels[index + 1];
      const currentB = pixels[index + 2];

      // Parar em linhas pretas
      if (isBlackPixel(currentR, currentG, currentB)) continue;

      // Verificar se é similar à cor inicial (tolerância para cores já pintadas)
      const colorDiff = Math.abs(currentR - startR) + Math.abs(currentG - startG) + Math.abs(currentB - startB);
      if (colorDiff > 100) continue;

      visited.add(key);
      points.push({ x, y });

      stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
    }

    return points;
  };

  const applyColorToImageData = (points: Point[], color: string) => {
    if (!coloredImageData || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const width = canvas.width;
    const data = new Uint8ClampedArray(coloredImageData.data);
    const [r, g, b] = hexToRgb(color);

    points.forEach(point => {
      const index = (point.y * width + point.x) * 4;
      
      // Só pintar se não for uma linha preta
      if (!isBlackPixel(data[index], data[index + 1], data[index + 2])) {
        data[index] = r;     // R
        data[index + 1] = g; // G
        data[index + 2] = b; // B
        // Alpha permanece o mesmo
      }
    });

    // Atualizar os dados da imagem colorida
    setColoredImageData(new ImageData(data, width, canvas.height));
  };

  const applyBrushToImageData = (points: Point[], color: string, size: number) => {
    if (!coloredImageData || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const width = canvas.width;
    const height = canvas.height;
    const data = new Uint8ClampedArray(coloredImageData.data);
    const [r, g, b] = hexToRgb(color);

    points.forEach(point => {
      // Aplicar pincel com tamanho
      const radius = size / 2;
      for (let dx = -radius; dx <= radius; dx++) {
        for (let dy = -radius; dy <= radius; dy++) {
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance <= radius) {
            const x = Math.round(point.x + dx);
            const y = Math.round(point.y + dy);
            
            if (x >= 0 && x < width && y >= 0 && y < height) {
              const index = (y * width + x) * 4;
              
              // Só pintar se não for uma linha preta
              if (!isBlackPixel(data[index], data[index + 1], data[index + 2])) {
                data[index] = r;     // R
                data[index + 1] = g; // G
                data[index + 2] = b; // B
              }
            }
          }
        }
      }
    });

    // Atualizar os dados da imagem colorida
    setColoredImageData(new ImageData(data, width, canvas.height));
  };

  const applyEraserToImageData = (points: Point[], size: number) => {
    if (!coloredImageData || !originalImageData || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const width = canvas.width;
    const height = canvas.height;
    const coloredData = new Uint8ClampedArray(coloredImageData.data);
    const originalData = originalImageData.data;

    points.forEach(point => {
      // Aplicar borracha com tamanho
      const radius = size / 2;
      for (let dx = -radius; dx <= radius; dx++) {
        for (let dy = -radius; dy <= radius; dy++) {
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance <= radius) {
            const x = Math.round(point.x + dx);
            const y = Math.round(point.y + dy);
            
            if (x >= 0 && x < width && y >= 0 && y < height) {
              const index = (y * width + x) * 4;
              
              // Restaurar cor original (preto e branco)
              coloredData[index] = originalData[index];         // R
              coloredData[index + 1] = originalData[index + 1]; // G
              coloredData[index + 2] = originalData[index + 2]; // B
              coloredData[index + 3] = originalData[index + 3]; // A
            }
          }
        }
      }
    });

    // Atualizar os dados da imagem colorida
    setColoredImageData(new ImageData(coloredData, width, canvas.height));
  };

  const redrawCanvas = () => {
    if (!canvasRef.current || !coloredImageData || !imageLoaded) {
      return;
    }
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Desenhar a imagem colorida atual
    ctx.putImageData(coloredImageData, 0, 0);

    // Desenhar traço atual se estiver desenhando
    if (isDrawing && currentPath.length > 0 && selectedColor) {
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (brushStyle === 'eraser') {
        // Mostrar preview da borracha
        ctx.save();
        ctx.globalCompositeOperation = 'source-over';
        ctx.beginPath();
        if (currentPath.length === 1) {
          ctx.arc(currentPath[0].x, currentPath[0].y, brushSize / 2, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(255, 0, 0, 0.5)';
          ctx.lineWidth = 2;
          ctx.stroke();
        } else {
          ctx.moveTo(currentPath[0].x, currentPath[0].y);
          currentPath.forEach(point => {
            ctx.lineTo(point.x, point.y);
          });
          ctx.lineWidth = brushSize;
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.stroke();
        }
        ctx.restore();
      } else {
        // Mostrar preview da cor
        ctx.save();
        ctx.globalAlpha = 0.7;
        ctx.beginPath();
        if (currentPath.length === 1) {
          ctx.arc(currentPath[0].x, currentPath[0].y, brushSize / 2, 0, Math.PI * 2);
          ctx.fillStyle = selectedColor;
          ctx.fill();
        } else {
          ctx.moveTo(currentPath[0].x, currentPath[0].y);
          currentPath.forEach(point => {
            ctx.lineTo(point.x, point.y);
          });
          ctx.strokeStyle = selectedColor;
          ctx.lineWidth = brushSize;
          ctx.stroke();
        }
        ctx.restore();
      }
    }
  };

  const getMousePos = (canvas: HTMLCanvasElement, evt: React.MouseEvent): Point => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (evt.clientX - rect.left) * scaleX,
      y: (evt.clientY - rect.top) * scaleY
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !selectedColor || !imageLoaded) return;
    
    const point = getMousePos(canvasRef.current, e);

    if (brushStyle === 'magic') {
      const points = floodFill(Math.round(point.x), Math.round(point.y));
      if (points.length > 0) {
        // Aplicar cor diretamente aos dados da imagem
        applyColorToImageData(points, selectedColor);
        
        // Criar região para histórico
        const newRegion: Region = {
          id: Date.now().toString(),
          points,
          color: selectedColor
        };
        onRegionCreated(newRegion);
        showSuccess();
      }
      return;
    }

    setIsDrawing(true);
    setCurrentPath([point]);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current || brushStyle === 'magic' || !imageLoaded) return;
    
    const point = getMousePos(canvasRef.current, e);
    setCurrentPath(prev => [...prev, point]);
  };

  const handleMouseUp = () => {
    if (!isDrawing || !selectedColor || brushStyle === 'magic' || !imageLoaded) {
      setIsDrawing(false);
      setCurrentPath([]);
      return;
    }

    if (currentPath.length > 0) {
      if (brushStyle === 'eraser') {
        // Aplicar borracha aos dados da imagem
        applyEraserToImageData(currentPath, brushSize);
      } else {
        // Aplicar cor aos dados da imagem
        applyBrushToImageData(currentPath, selectedColor, brushSize);
      }

      // Criar região para histórico
      const newRegion: Region = {
        id: Date.now().toString(),
        points: [...currentPath],
        color: brushStyle === 'eraser' ? 'ERASER' : selectedColor
      };
      onRegionCreated(newRegion);
      showSuccess();
    }

    setIsDrawing(false);
    setCurrentPath([]);
  };

  const showSuccess = () => {
    const randomMessage = successMessages[Math.floor(Math.random() * successMessages.length)];
    setSuccessMessage(randomMessage);
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const dataUrl = canvas.toDataURL('image/png');
    
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `minha-obra-de-arte-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setSuccessMessage('🎉 Sua obra de arte foi salva! Que lindo trabalho!');
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 4000);
  };

  const handlePrint = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const dataUrl = canvas.toDataURL('image/png');
    
    // Criar uma nova janela para impressão
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    
    if (printWindow) {
      printWindow.document.open();
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Minha Obra de Arte - Colorir é Divertido</title>
            <meta charset="UTF-8">
            <style>
              * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
              }
              
              body {
                font-family: 'Arial', sans-serif;
                background: white;
                padding: 20px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
              }
              
              .header {
                text-align: center;
                margin-bottom: 20px;
                color: #7c3aed;
              }
              
              .header h1 {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 5px;
              }
              
              .header p {
                font-size: 14px;
                color: #666;
              }
              
              .artwork-container {
                border: 3px solid #7c3aed;
                border-radius: 15px;
                padding: 10px;
                background: white;
                box-shadow: 0 4px 12px rgba(124, 58, 237, 0.1);
              }
              
              .artwork {
                max-width: 100%;
                height: auto;
                border-radius: 10px;
                display: block;
              }
              
              .footer {
                margin-top: 20px;
                text-align: center;
                color: #7c3aed;
                font-size: 12px;
              }
              
              @media print {
                body {
                  padding: 10px;
                }
                
                .header h1 {
                  font-size: 18px;
                }
                
                .artwork-container {
                  border: 2px solid #333;
                  box-shadow: none;
                  page-break-inside: avoid;
                }
                
                .footer {
                  font-size: 10px;
                  color: #333;
                }
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>🎨 Minha Obra de Arte 🎨</h1>
              <p>Criado no app "Colorir é Divertido!"</p>
            </div>
            
            <div class="artwork-container">
              <img src="${dataUrl}" alt="Minha Obra de Arte Colorida" class="artwork" />
            </div>
            
            <div class="footer">
              <p>✨ Feito com muito amor e criatividade! ✨</p>
              <p>Data: ${new Date().toLocaleDateString('pt-BR')}</p>
            </div>
            
            <script>
              // Aguardar a imagem carregar antes de imprimir
              window.onload = function() {
                setTimeout(function() {
                  window.print();
                  // Fechar janela após impressão (opcional)
                  window.onafterprint = function() {
                    window.close();
                  };
                }, 500);
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    } else {
      // Fallback se popup foi bloqueado
      alert('Por favor, permita pop-ups para imprimir sua obra de arte! 🖨️');
    }
    
    setSuccessMessage('🖨️ Preparando sua obra de arte para imprimir!');
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
  };

  const getCursorStyle = () => {
    switch (brushStyle) {
      case 'brush':
        return 'cursor-crosshair';
      case 'eraser':
        return 'cursor-crosshair';
      case 'magic':
        return 'cursor-pointer';
      case 'region':
        return 'cursor-crosshair';
      default:
        return 'cursor-crosshair';
    }
  };

  // Estado de carregamento
  if (isLoading) {
    return (
      <div 
        ref={containerRef}
        className="relative bg-white rounded-2xl shadow-xl overflow-hidden border-4 border-purple-100 flex items-center justify-center"
        style={{ minHeight: '400px' }}
      >
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4 mx-auto"></div>
          <p className="text-purple-700 font-bold text-lg">Preparando desenho para colorir...</p>
          <p className="text-gray-600">Convertendo para preto e branco! 🎨</p>
        </div>
      </div>
    );
  }

  // Se não há URL de imagem
  if (!imageUrl) {
    return null;
  }

  return (
    <div 
      ref={containerRef}
      className="relative bg-white rounded-2xl shadow-xl overflow-hidden border-4 border-purple-100"
    >
      <canvas
        ref={canvasRef}
        width={canvasSize.width}
        height={canvasSize.height}
        className={`${getCursorStyle()} block mx-auto`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ 
          maxWidth: '100%',
          height: 'auto'
        }}
      />
      
      {showSuccessMessage && (
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-green-400 to-green-500 text-white px-6 py-3 rounded-full shadow-lg flex items-center animate-bounce z-10">
          <Heart className="w-5 h-5 mr-2 animate-pulse" />
          <span className="font-bold text-lg">{successMessage}</span>
        </div>
      )}
      
      {isDrawing && brushStyle !== 'magic' && (
        <div className="absolute top-4 left-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 px-4 rounded-full text-sm font-bold shadow-lg flex items-center z-10">
          <div className="w-3 h-3 bg-white rounded-full mr-2 animate-pulse"></div>
          {brushStyle === 'eraser' ? 'Apagando...' : 'Colorindo...'}
        </div>
      )}
      
      {regions.length > 0 && imageLoaded && (
        <div className="absolute bottom-4 right-4 flex gap-3 z-10">
          <button
            onClick={handlePrint}
            className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white py-3 px-6 rounded-full shadow-lg transition-all transform hover:scale-105 flex items-center font-bold"
          >
            <Printer className="w-5 h-5 mr-2" />
            Imprimir! 🖨️
          </button>
          <button
            onClick={handleDownload}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white py-3 px-6 rounded-full shadow-lg transition-all transform hover:scale-105 flex items-center font-bold"
          >
            <Download className="w-5 h-5 mr-2" />
            Salvar! 🎨
          </button>
        </div>
      )}
      
      {imageLoaded && (
        <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full text-sm text-gray-700 shadow-md border border-purple-200 z-10">
          <div className="flex items-center">
            <Palette className="w-4 h-4 mr-2 text-purple-600" />
            {brushStyle === 'magic' ? '✨ Clique em uma área branca para pintar magicamente!' : 
             brushStyle === 'brush' ? '🖌️ Clique e arraste para desenhar!' :
             brushStyle === 'eraser' ? '🧽 Clique e arraste para apagar!' :
             '📝 Desenhe ao redor da área que você quer colorir!'}
          </div>
        </div>
      )}
    </div>
  );
};

export default ColoringCanvas;