import React from 'react';
import { BrushStyle } from '../types';
import { Brush, Square, Eraser, Wand2, Palette } from 'lucide-react';

interface BrushSelectorProps {
  selectedStyle: BrushStyle;
  onSelectStyle: (style: BrushStyle) => void;
  brushSize: number;
  onBrushSizeChange: (size: number) => void;
}

const BrushSelector: React.FC<BrushSelectorProps> = ({ 
  selectedStyle, 
  onSelectStyle,
  brushSize,
  onBrushSizeChange
}) => {
  const tools = [
    {
      style: 'brush' as BrushStyle,
      icon: <Brush className="w-8 h-8" />,
      name: 'Pincel',
      description: 'Desenhe livremente',
      color: 'from-blue-500 to-blue-600'
    },
    {
      style: 'region' as BrushStyle,
      icon: <Square className="w-8 h-8" />,
      name: 'Região',
      description: 'Selecione áreas',
      color: 'from-green-500 to-green-600'
    },
    {
      style: 'magic' as BrushStyle,
      icon: <Wand2 className="w-8 h-8" />,
      name: 'Mágico',
      description: 'Pinte automaticamente',
      color: 'from-purple-500 to-purple-600'
    },
    {
      style: 'eraser' as BrushStyle,
      icon: <Eraser className="w-8 h-8" />,
      name: 'Borracha',
      description: 'Apague desenhos',
      color: 'from-red-500 to-red-600'
    }
  ];

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-purple-100">
      <div className="flex items-center justify-center mb-6">
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-2 rounded-full mr-3">
          <Palette className="w-6 h-6 text-white" />
        </div>
        <h3 className="text-xl font-bold text-purple-700">Ferramentas Mágicas</h3>
      </div>
      
      <div className="grid grid-cols-2 gap-3 mb-6">
        {tools.map((tool) => (
          <button
            key={tool.style}
            className={`p-4 rounded-xl flex flex-col items-center transition-all duration-300 transform hover:scale-105 ${
              selectedStyle === tool.style 
                ? `bg-gradient-to-br ${tool.color} text-white shadow-lg ring-4 ring-purple-200` 
                : 'bg-gray-50 hover:bg-gray-100 text-gray-700 hover:shadow-md'
            }`}
            onClick={() => onSelectStyle(tool.style)}
          >
            <div className={`mb-2 ${selectedStyle === tool.style ? 'text-white' : 'text-purple-600'}`}>
              {tool.icon}
            </div>
            <span className="font-bold text-sm">{tool.name}</span>
            <span className={`text-xs mt-1 ${selectedStyle === tool.style ? 'text-white/90' : 'text-gray-500'}`}>
              {tool.description}
            </span>
          </button>
        ))}
      </div>
      
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl">
        <label className="block text-sm font-bold text-purple-700 mb-3 text-center">
          Tamanho da Ferramenta: {brushSize}px
        </label>
        <div className="relative">
          <input
            type="range"
            min="5"
            max="50"
            value={brushSize}
            onChange={(e) => onBrushSizeChange(Number(e.target.value))}
            className="w-full h-3 bg-gradient-to-r from-purple-200 to-pink-200 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-2">
            <span>Pequeno</span>
            <span>Grande</span>
          </div>
        </div>
        
        {/* Preview circle */}
        <div className="flex justify-center mt-4">
          <div className="bg-white p-3 rounded-lg shadow-inner">
            <div 
              className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
              style={{ 
                width: `${Math.max(brushSize / 2, 8)}px`, 
                height: `${Math.max(brushSize / 2, 8)}px` 
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default BrushSelector;