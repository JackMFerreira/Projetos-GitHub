import React from 'react';
import { Upload } from 'lucide-react';

interface SampleImagesProps {
  onImageSelected: (imageUrl: string) => void;
  importedImages?: string[];
}

const SampleImages: React.FC<SampleImagesProps> = ({ onImageSelected, importedImages = [] }) => {
  // Se não há imagens importadas, não mostrar nada
  if (importedImages.length === 0) {
    return null;
  }

  // Apenas imagens importadas
  const allImages = importedImages.map((url, index) => ({
    id: `imported-${index}`,
    name: `Desenho ${index + 1}`,
    url,
    icon: <Upload className="w-5 h-5" />
  }));

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-purple-100">
      <div className="text-center mb-6">
        <h2 className="text-3xl font-bold text-purple-700 mb-2">
          🎨 Seus Desenhos Importados! 🎨
        </h2>
        <p className="text-lg text-gray-600">
          Clique em um desenho para começar a colorir
        </p>
        <div className="mt-4 p-3 bg-purple-50 rounded-xl border-2 border-purple-200">
          <p className="text-purple-700 font-medium">
            ✨ <strong>{importedImages.length}</strong> desenho{importedImages.length !== 1 ? 's' : ''} importado{importedImages.length !== 1 ? 's' : ''} do seu PDF!
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {allImages.map((image) => (
          <button
            key={image.id}
            onClick={() => onImageSelected(image.url)}
            className="group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-purple-50 to-pink-50 p-3 border-2 border-purple-100 hover:border-purple-300"
          >
            {/* Ícone e nome */}
            <div className="flex items-center justify-center mb-2">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-1.5 rounded-full text-white shadow-md mr-2">
                {image.icon}
              </div>
              <h3 className="font-bold text-purple-700 group-hover:text-purple-800 text-xs text-center flex-1">
                {image.name}
              </h3>
            </div>
            
            {/* Imagem do desenho */}
            <div className="relative h-20 rounded-lg overflow-hidden bg-gray-50 border border-gray-200 flex items-center justify-center">
              <img
                src={image.url}
                alt={`${image.name} - Desenho para colorir`}
                className="max-w-full max-h-full object-contain group-hover:scale-110 transition-transform duration-300"
                loading="lazy"
              />
              
              {/* Overlay de hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-purple-600/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-bold text-purple-700 shadow-md">
                  ✨ Colorir!
                </div>
              </div>
              
              {/* Badge para desenhos importados */}
              <div className="absolute top-1 right-1 bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-1.5 py-0.5 rounded-full text-xs font-bold shadow-md">
                📄
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SampleImages;