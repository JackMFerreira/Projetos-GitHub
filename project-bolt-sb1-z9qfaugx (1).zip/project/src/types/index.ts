export interface Point {
  x: number;
  y: number;
}

export interface Region {
  id: string;
  points: Point[];
  color: string | null;
}

export interface ColorOption {
  name: string;
  value: string;
}

export type BrushStyle = 'region' | 'brush' | 'eraser' | 'magic';