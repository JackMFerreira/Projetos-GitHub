import React, { useState } from 'react';
import Header from './components/Header';
import ImageUpload from './components/ImageUpload';
import ColoringCanvas from './components/ColoringCanvas';
import ColorPalette from './components/ColorPalette';
import BrushSelector from './components/BrushSelector';
import Instructions from './components/Instructions';
import SampleImages from './components/SampleImages';
import EbookImporter from './components/EbookImporter';
import { colors } from './utils/colors';
import { Region, BrushStyle } from './types';
import { RotateCcw, Trash2, Volume2, VolumeX, Upload, QrCode } from 'lucide-react';

function App() {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<string | null>(colors[0].value);
  const [regions, setRegions] = useState<Region[]>([]);
  const [regionsHistory, setRegionsHistory] = useState<Region[][]>([[]]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [brushStyle, setBrushStyle] = useState<BrushStyle>('brush');
  const [brushSize, setBrushSize] = useState(15);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showEbookImporter, setShowEbookImporter] = useState(false);
  const [importedImages, setImportedImages] = useState<string[]>([]);

  const playSound = (type: 'click' | 'success' | 'undo') => {
    if (!soundEnabled) return;
    
    // Create audio context for sound feedback
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    switch (type) {
      case 'click':
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        break;
      case 'success':
        oscillator.frequency.setValueAtTime(1000, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        break;
      case 'undo':
        oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        break;
    }
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.1);
  };

  const handleImageUploaded = (url: string) => {
    setImageUrl(url);
    setRegions([]);
    setRegionsHistory([[]]);
    setHistoryIndex(0);
    playSound('success');
  };

  const handleRegionCreated = (region: Region) => {
    const newRegions = [...regions, region];
    setRegions(newRegions);
    
    // Remove any future history after current index
    const newHistory = regionsHistory.slice(0, historyIndex + 1);
    setRegionsHistory([...newHistory, newRegions]);
    setHistoryIndex(historyIndex + 1);
    playSound('click');
  };

  const handleColorSelect = (color: string) => {
    setSelectedColor(color);
    playSound('click');
  };

  const handleRemoveImage = () => {
    setImageUrl(null);
    setRegions([]);
    setRegionsHistory([[]]);
    setHistoryIndex(0);
    playSound('click');
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setRegions(regionsHistory[newIndex]);
      playSound('undo');
    }
  };

  const handleClearAll = () => {
    setRegions([]);
    setRegionsHistory([[]]);
    setHistoryIndex(0);
    playSound('click');
  };

  const handleBrushStyleChange = (style: BrushStyle) => {
    setBrushStyle(style);
    playSound('click');
  };

  const handleEbookImport = (images: string[]) => {
    setImportedImages(prev => [...prev, ...images]);
    playSound('success');
  };

  const canUndo = historyIndex > 0;
  const hasDrawings = regions.length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-50 to-pink-100">
      <Header />
      
      <main className="container mx-auto px-4 py-4">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-3/4">
            {!imageUrl ? (
              <div className="space-y-6">
                <div className="flex justify-center gap-4 mb-6">
                  <button
                    onClick={() => setShowEbookImporter(true)}
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-bold py-4 px-8 rounded-full shadow-lg transition-all transform hover:scale-105 flex items-center space-x-3 text-lg"
                  >
                    <Upload className="w-7 h-7" />
                    <span>📥 Importar Ebook!</span>
                  </button>
                </div>
                
                <SampleImages 
                  onImageSelected={handleImageUploaded} 
                  importedImages={importedImages}
                />
                <div className="text-center">
                  <div className="inline-block bg-white p-2 rounded-full shadow-lg mb-4">
                    <span className="text-2xl">✨</span>
                  </div>
                  <h2 className="text-xl font-bold text-purple-700 mb-2">
                    Ou envie sua própria imagem
                  </h2>
                </div>
                <ImageUpload onImageUploaded={handleImageUploaded} />
              </div>
            ) : (
              <div className="space-y-4">
                <Instructions />
                <div className="relative">
                  <ColoringCanvas 
                    imageUrl={imageUrl} 
                    regions={regions}
                    selectedColor={selectedColor}
                    brushStyle={brushStyle}
                    brushSize={brushSize}
                    onRegionCreated={handleRegionCreated}
                  />
                  <div className="absolute top-2 right-2 flex gap-2 flex-wrap">
                    <button
                      onClick={() => setSoundEnabled(!soundEnabled)}
                      className="bg-yellow-500 hover:bg-yellow-600 text-white p-2 rounded-full shadow-md transition-all transform hover:scale-105"
                      title={soundEnabled ? 'Desativar sons' : 'Ativar sons'}
                    >
                      {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                    </button>
                    <button
                      onClick={handleUndo}
                      disabled={!canUndo}
                      className={`bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-full shadow-md transition-all transform hover:scale-105 flex items-center ${
                        !canUndo ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      <RotateCcw className="w-5 h-5 mr-1" />
                      Desfazer
                    </button>
                    {hasDrawings && (
                      <button
                        onClick={handleClearAll}
                        className="bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded-full shadow-md transition-all transform hover:scale-105 flex items-center"
                      >
                        <Trash2 className="w-5 h-5 mr-1" />
                        Limpar Tudo
                      </button>
                    )}
                    <button
                      onClick={handleRemoveImage}
                      className="bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded-full shadow-md transition-all transform hover:scale-105"
                    >
                      Nova Imagem
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="lg:w-1/4 space-y-4">
            {imageUrl && (
              <BrushSelector 
                selectedStyle={brushStyle}
                onSelectStyle={handleBrushStyleChange}
                brushSize={brushSize}
                onBrushSizeChange={setBrushSize}
              />
            )}
            <ColorPalette 
              colors={colors} 
              selectedColor={selectedColor} 
              onSelectColor={handleColorSelect} 
            />
          </div>
        </div>
      </main>
      
      <footer className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-6 text-center mt-12">
        <div className="container mx-auto">
          <p className="text-lg font-medium">🎨 Colorir é Divertido 🎨</p>
          <p className="text-sm opacity-90 mt-1">Desenvolvido com ❤️ para crianças</p>
        </div>
      </footer>
      
      {showEbookImporter && (
        <EbookImporter 
          onClose={() => setShowEbookImporter(false)}
          onImportSuccess={handleEbookImport}
          onImageSelected={handleImageUploaded}
        />
      )}
    </div>
  );
}

export default App;