import { ColorOption } from '../types';

export const colors: ColorOption[] = [
  // Cores básicas
  { name: 'Vermelho', value: '#FF0000' },
  { name: 'Verde', value: '#00FF00' },
  { name: 'Azul', value: '#0000FF' },
  { name: 'Amarelo', value: '#FFFF00' },
  { name: 'Roxo', value: '#800080' },
  { name: 'Laranja', value: '#FFA500' },
  
  // Tons pastéis
  { name: 'Rosa Claro', value: '#FFB6C1' },
  { name: 'Azul Bebê', value: '#89CFF0' },
  { name: 'Verde Menta', value: '#98FF98' },
  { name: 'Lavanda', value: '#E6E6FA' },
  { name: 'Pêssego', value: '#FFDAB9' },
  { name: 'Amarelo Claro', value: '#FFFACD' },
  
  // Tons terrosos
  { name: 'Marrom', value: '#8B4513' },
  { name: 'Bege', value: '#F5F5DC' },
  { name: 'Terracota', value: '#E2725B' },
  { name: 'Caramelo', value: '#D2691E' },
  { name: 'Café', value: '#6F4E37' },
  { name: 'Areia', value: '#F4A460' },
  
  // Tons vibrantes
  { name: 'Pink', value: '#FF69B4' },
  { name: 'Turquesa', value: '#40E0D0' },
  { name: 'Lima', value: '#32CD32' },
  { name: 'Coral', value: '#FF7F50' },
  { name: 'Violeta', value: '#8A2BE2' },
  { name: 'Magenta', value: '#FF00FF' },
  
  // Tons metálicos
  { name: 'Dourado', value: '#FFD700' },
  { name: 'Prata', value: '#C0C0C0' },
  { name: 'Bronze', value: '#CD7F32' },
  
  // Tons neutros
  { name: 'Preto', value: '#000000' },
  { name: 'Branco', value: '#FFFFFF' },
  { name: 'Cinza Claro', value: '#D3D3D3' },
  { name: 'Cinza Escuro', value: '#696969' },
];